exports.cliVersion = '>=3.X';

exports.init = function(logger, config, cli, appc) {
    cli.on('build.android.aapt', {
        pre: function(data, next) {
            var args = data.args[1],
                i18n = appc.i18n(__dirname),
                __ = i18n.__,
                path = require('path'),
                appDir = path.join(cli.argv['project-dir'], 'app'),
                find = function(items, f) {
                    for (var i = 0; i < items.length; i++) {
                        var item = items[i];
                        if (f(item)) return item;
                    };
                },
                module = false;
            if (args.indexOf('--auto-add-overlay') < 0) {
                args.push('--auto-add-overlay');
            }
            for(var i in cli.tiapp.modules) {
                if (cli.tiapp.modules[i].id == "ti.intercom.android") {
                    module = cli.tiapp.modules[i];
                    break;
                }
            }
            if (!module) {
                logger.error(__('Unable to determine Android Intercom module version.  You must specify the module version specfically in your tiapp.xml'));
                process.exit(1);
            } else {
                var externalLibraries = [{
                    javaClass: 'io.intercom.android.sdk.gcm',
                    resPath: appDir + '/../modules/android/ti.intercom.android/' + module.version + '/platform/android/gcm-res'
                }];
                logger.info(__("Add Intercom GCM External Libraries" + JSON.stringify(externalLibraries)));

                // --extra-packages can be defined just once
                if (args.indexOf('--extra-packages') < 0) {
                    args.push('--extra-packages');
                    args.push('');
                }
                var namespaceIndex = args.indexOf('--extra-packages') + 1;

                externalLibraries.forEach(function(lib) {
                    if (args[namespaceIndex].indexOf(lib.javaClass) < 0) {
                        args[namespaceIndex].length && (args[namespaceIndex] += ':');
                        args[namespaceIndex] += lib.javaClass;
                    }
                    if (args.indexOf(lib.resPath) < 0) {
                        args.push('-S');
                        args.push(lib.resPath);
                    }
                });
                next(null, data);
            }

        }
    });
};
